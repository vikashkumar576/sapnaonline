import Image from "next/image"
import Link from "next/link"

const Exam = ()=>{
    return(
        <div className="container w-[88%] mx-auto">
            <div className="border-b bg-white flex justify-between px-3 py-2 items-center">
                <p className="capitalize text-[#282c96] font-semibold">shop by Exams</p>
                <Link href={'/'} legacyBehavior >
                    <button className="uppercase bg-[#282c96] px-2.5 rounded py-1.5 font-semibold text-white text-sm">view all</button>
                </Link>
            </div>
            <div className="">
                <div className="">
                    <button className="bg-white p-6 border-orange-500 border rounded-full">
                        <Image src={'/sapnaHome/exam-1.png'} alt="exam-1" width={40} height={50} />
                    </button>
                </div>
            </div>
        </div>
    )
}

export default Exam
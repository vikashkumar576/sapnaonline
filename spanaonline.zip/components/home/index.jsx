import Layout from "../shared/layout";
import Hero from "./hero";
import Releases from "./releases";
import Advertise from "./advertise";
import Exam from "./exam";
import Test from "./test";

 const Home = ()=>{
   return (
        <Layout title="Buy Books Online,Bookstore In Convinient price">
            <Hero/>
            {/* <Test/> */}
            <Releases />
            <Advertise/>
            <Exam />
        </Layout>
   )
 }
 
 export default Home